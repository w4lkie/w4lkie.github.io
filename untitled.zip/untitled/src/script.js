document.addEventListener('DOMContentLoaded', function() {
    const greeting = "Hello my name is ";
    const name = "Brian Walker";
    const typewriterElement = document.getElementById("typewriter");
    const nameTextElement = document.getElementById("name-text");
    const nameContainer = document.getElementById("name-container");
    let i = 0;
    let j = 0;
    let isTypingName = false;

    function type() {
        if (!isTypingName) {
            // Typing the greeting
            if (i < greeting.length) {
                typewriterElement.textContent += greeting.charAt(i);
                i++;
                setTimeout(type, 100); // Speed for greeting
            } else {
                isTypingName = true;
                nameContainer.style.opacity = "1"; // Show name container
                setTimeout(type, 200); // Brief pause before name
            }
        } else {
            // Typing the name
            if (j < name.length) {
                nameTextElement.textContent += name.charAt(j);
                j++;
                setTimeout(type, 100); // Speed for name
            }
            // Animation stops automatically when done
        }
    }

    // Initialize AOS
    AOS.init();
    
    // Start the typewriter effect
    setTimeout(type, 500); // Initial delay before starting
});